package trywildcard;
public class Tester {
    
    
}
