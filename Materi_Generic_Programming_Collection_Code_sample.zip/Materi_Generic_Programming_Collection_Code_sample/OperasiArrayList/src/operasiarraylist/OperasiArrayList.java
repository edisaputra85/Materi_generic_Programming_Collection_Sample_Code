package operasiarraylist;
import java.util.ArrayList;
public class OperasiArrayList {
    public static void main(String[] args) {
        //operasi add
        ArrayList<String> nama = new ArrayList<>();       
        nama.add("Ani");//nama[0]="Ani"
        nama.add("Budi");//nama[1]="Budi"
        nama.add("Elsa");//nama[2]="Elsa"
        nama.add("Herti");//nama[3]="Herti"
        System.out.println("List nama setelah operasi add");
        System.out.println("==============================");
        
        //looping satu per satu element
        for (String name: nama){ 
            System.out.println(name);
        }
        
        //operasi menyisipkan nama zaenal di posisi ketiga
        nama.add(1,"Zaenal");
        System.out.println("List nama setelah disisipkan nama Zaenal");
        System.out.println("==============================");
        //looping satu per satu element
        nama.forEach((name) -> { 
            System.out.println(name);
        }); 
        
        nama.remove(2);
        System.out.println("List nama setelah Budi dihilangkan");
        System.out.println("==============================");
        //looping satu per satu element
        nama.forEach((name) -> { 
            System.out.println(name);
        });  
        System.out.println("Jumlah elemen ArrayList nama = " + nama.size());
        
    }   
}
