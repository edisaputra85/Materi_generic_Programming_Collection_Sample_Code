package objectgeneric;
public class Tester2 {
    public static void main(String[] args) {
    PertukaranNilai pertukarannilai = new PertukaranNilai();
        Integer a=10;
        Integer b=20;
        pertukarannilai.setDataSatu(a);        
        pertukarannilai.setDataDua(b);
        
        System.out.println("Tampilkan nilai sebelum tukar ");
        pertukarannilai.tampilNilai();
        pertukarannilai.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        pertukarannilai.tampilNilai();    
        
        System.out.println();
        
        String nama1="Adam";
        String nama2="Hawa";
        pertukarannilai.setDataSatu(nama1);
        pertukarannilai.setDataDua(nama2);
        
        System.out.println("Tampilkan nilai sebelum tukar ");
        pertukarannilai.tampilNilai();
        pertukarannilai.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        pertukarannilai.tampilNilai();
    }
}
