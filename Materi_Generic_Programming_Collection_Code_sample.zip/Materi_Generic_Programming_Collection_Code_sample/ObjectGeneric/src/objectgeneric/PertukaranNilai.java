package objectgeneric;
public class PertukaranNilai {
   private Object dataSatu;
   private Object dataDua;
   private Object temp;
   
   public Object getDataSatu(){
       return dataSatu;
   }
   public void setDataSatu(Object dataSatu){
       this.dataSatu=dataSatu;
   }
   
   public Object getDataDua(){
       return dataDua;
   }
   public void setDataDua(Object dataDua){
       this.dataDua=dataDua;
   }
   
   public void tukarNilai(){
       temp = dataSatu;
       dataSatu = dataDua;
       dataDua = temp;
   }
   
   public void tampilNilai(){
       System.out.println("dataSatu = "+dataSatu);
       System.out.println("dataDua = "+dataDua);
   }
}
