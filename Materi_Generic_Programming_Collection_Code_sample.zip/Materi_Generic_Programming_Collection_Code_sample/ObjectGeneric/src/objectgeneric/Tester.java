package objectgeneric;
public class Tester {
    public static void main(String[] args) {
        PertukaranNilai pertukarannilai = new PertukaranNilai();
        //dataSatu bertipe object, tetapi ketika diberikan nilai 10, maka tipe berubah menjadi kelas Integer
        pertukarannilai.setDataSatu(10);
        //dataDua bertipe object, tetapi ketika diberikan nilai 20, maka tipe berubah menjadi kelas Integer
        pertukarannilai.setDataDua(20);
        
        System.out.println("Tampilkan nilai sebelum tukar ");
        pertukarannilai.tampilNilai();
        pertukarannilai.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        pertukarannilai.tampilNilai();    
        
        System.out.println();
        
        //dataSatu bertipe object, tetapi ketika diberikan nilai Adam, maka tipe berubah menjadi kelas String
        pertukarannilai.setDataSatu("Adam");
        //dataDua bertipe object, tetapi ketika diberikan nilai Hawa, maka tipe berubah menjadi kelas String
        pertukarannilai.setDataDua("Hawa");
        
        System.out.println("Tampilkan nilai sebelum tukar ");
        pertukarannilai.tampilNilai();
        pertukarannilai.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        pertukarannilai.tampilNilai();
    
    }  
}
