package taggeneric;
public class PertukaranNilai<K,F> {
   private K dataSatu;
   private F dataDua;
   private K temp;
   
   public K getDataSatu(){
       return dataSatu;
   }
   public void setDataSatu(K dataSatu){
       this.dataSatu=dataSatu;
   }
   
   public F getDataDua(){
       return dataDua;
   }
   public void setDataDua(F dataDua){
       this.dataDua=dataDua;
   }
   
   public void tukarNilai(){
       temp = dataSatu;
       dataSatu = (K)dataDua;
       dataDua = (F)temp;
   }
   
   public void tampilNilai(){
       System.out.println("dataSatu = "+dataSatu);
       System.out.println("dataDua = "+dataDua);
   }
}
