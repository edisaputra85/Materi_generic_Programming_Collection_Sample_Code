package taggeneric;
public class Tester {
    public static void main(String[] args) {
        //tag <E> pada kelas PertukaranNilai diganti dengan kelas tipe data Integer
        PertukaranNilai<Integer,Double> tukarinteger = new PertukaranNilai<>();
        tukarinteger.setDataSatu(10);
        tukarinteger.setDataDua(20.0);
        System.out.println("Tampilkan nilai sebelum tukar ");
        tukarinteger.tampilNilai();
        tukarinteger.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        tukarinteger.tampilNilai();    
        
        System.out.println();
        /*
        //tag <E> pada kelas PertukaranNilai diganti dengan kelas tipe data String
        PertukaranNilai<String> tukarstring = new PertukaranNilai<>();
        tukarstring.setDataSatu("Adam");
        tukarstring.setDataDua("Hawa");
        
        System.out.println("Tampilkan nilai sebelum tukar ");
        tukarstring.tampilNilai();
        tukarstring.tukarNilai();
        System.out.println("Tampilkan hasil tukar ");
        tukarstring.tampilNilai();
*/
    }  
}
