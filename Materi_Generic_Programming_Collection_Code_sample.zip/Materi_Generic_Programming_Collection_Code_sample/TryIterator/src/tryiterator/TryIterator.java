package tryiterator;
import java.util.ArrayList;
import java.util.Iterator;
public class TryIterator {
    public static void main(String[] args) {
       //Instansiasi objek dari kelas ArrayList
       ArrayList<Integer> bilanganbulat = new ArrayList<>();
       
       //Pengisian nilai Array
       bilanganbulat.add(10);//bilanganbulat[0] = 10;
       bilanganbulat.add(20);//bilanganbulat[1] = 20;
       bilanganbulat.add(30);
       bilanganbulat.add(40);
       bilanganbulat.add(50);//bilanganbulat[4] = 50;
       
       //instansiasi objek iterator yang dikaitkan dengan ArrayList bilanganbulat
       Iterator iterator = bilanganbulat.iterator();
       //lakukan perulangan selama iterator masih memiliki data untuk dibaca
       while (iterator.hasNext()){
           //iterator.next() mengembalikan nilai bertipe objek
           Object elemen = iterator.next();//baca melalui iterator
           System.out.println(elemen);
       }     
    }   
}
