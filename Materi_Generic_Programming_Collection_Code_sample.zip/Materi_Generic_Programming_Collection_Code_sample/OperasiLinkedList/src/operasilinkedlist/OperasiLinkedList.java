package operasilinkedlist;
import java.util.LinkedList;
public class OperasiLinkedList {
    public static void main(String[] args) {
        //coba operasi addFirst, addLast, dan add ke posisi tertentu
        LinkedList<String> nama = new LinkedList<>();
        String namaDibuang ;
        nama.addFirst("Elsa"); //nama[0]="Elsa"
        nama.addFirst("Zaenal");//nama[0]="Zaenal:;nama[1]="Elsa"
        nama.addLast("Herti");//nama[0]="Zaenal; nama[1]="Elsa"; nama[2]="Herti"
        nama.add("Vano");//nama[0]="Zaenal; nama[1]="Elsa"; nama[2]="Herti" ; nama[3]="Vano"
        nama.add(2,"Vivi");//nama[0]="Zaenal; nama[1]="Elsa"; nama[2]="Vivi"; nama[3]="Herti" ; nama[4]="Vano"
        
        System.out.println("List nama setelah operasi addFirst, addLast, dan add ke posisi tertentu");
        System.out.println("========================================================================");
        //looping satu per satu element
        for (String name: nama){ 
            System.out.println(name);
        } 
        
        nama.removeLast();
        namaDibuang = nama.removeFirst();
        System.out.println("List nama setelah operasi removeLast dan removeFirst");
        System.out.println("========================================================================");
        //looping satu per satu element
        for (String name: nama){ 
            System.out.println(name);
        } 
        
        //getFirst dan getLast
        System.out.println("nama pertama adalah" + nama.getFirst());
        System.out.println("nama terakhir adalah" + nama.getLast());     
        //dapatkan nama indeks ke-3
        System.out.println("nama indeks ketiga adalah" + nama.get(3));    
    }  
}
